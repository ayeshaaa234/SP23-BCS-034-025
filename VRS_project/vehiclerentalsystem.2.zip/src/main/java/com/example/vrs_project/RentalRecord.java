package com.example.vrs_project;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

public class RentalRecord implements Serializable {
    private String vehicleType;
    private String rentedBy;
    private Date dateRented;
    private String model;
    private String name;

    private Vehicle vehicle;
    private LocalDate dateReturned;


    public RentalRecord(String vehicleType, String rentedBy, Date dateRented,LocalDate dateReturned) {
        this.vehicleType = vehicleType;
        this.rentedBy = rentedBy;
        this.dateRented = dateRented;
        this.dateReturned=null;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public String getRentedBy() {
        return rentedBy;
    }


    public Date getDateRented() {
        return dateRented;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }


    public LocalDate getDateReturned() {

        return dateReturned;
    }

    public void setDateReturned(LocalDate dateReturned) {
        this.dateReturned = dateReturned;
    }
}
